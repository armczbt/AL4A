void main(void) {
  int a;
  a = 0x123;
}
