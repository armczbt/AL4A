void main(void) {
  int a;
  a = 123 + 321 * 4 / 2 - 1;
}
