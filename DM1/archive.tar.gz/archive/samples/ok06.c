void main(void) {
  int a;
  a = 123 + 321;
}
