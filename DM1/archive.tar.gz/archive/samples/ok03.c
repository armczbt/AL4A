void main(void) {
  int abcd;
}
