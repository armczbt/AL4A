void _main(void) {
 int a = # 123;
}
