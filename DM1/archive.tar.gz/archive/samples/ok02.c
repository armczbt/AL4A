void main(void) {
  int a;
}
